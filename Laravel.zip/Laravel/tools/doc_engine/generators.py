from pathlib import Path
from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
from pptx import Presentation
from pptx.util import Inches as PptxInches, Pt as PptxPt
from fpdf import FPDF
import uuid
import json

OUTPUT_DIR = Path("outputs")
OUTPUT_DIR.mkdir(exist_ok=True)

# === Base Generator Classes ===

class BaseDocx:
    def __init__(self):
        self.doc = Document()
        style = self.doc.styles['Normal']
        font = style.font
        font.name = 'Calibri'
        font.size = Pt(11)
    
    def add_heading(self, text, level=1):
        h = self.doc.add_heading(text, level=level)
        h.alignment = WD_ALIGN_PARAGRAPH.LEFT
        return h
    
    def add_para(self, text, bold=False, align=None):
        p = self.doc.add_paragraph(text)
        if bold:
            for run in p.runs:
                run.bold = True
        if align:
            p.alignment = align
        return p
    
    def add_table(self, rows, cols, data, headers=None):
        table = self.doc.add_table(rows=rows, cols=cols)
        table.style = 'Table Grid'
        if headers:
            for i, h in enumerate(headers):
                cell = table.rows[0].cells[i]
                cell.text = h
                for run in cell.paragraphs[0].runs:
                    run.bold = True
        for r_idx, row in enumerate(data):
            for c_idx, val in enumerate(row):
                table.rows[r_idx + (1 if headers else 0)].cells[c_idx].text = str(val)
        return table
    
    def save(self, filename):
        path = OUTPUT_DIR / filename
        self.doc.save(path)
        return str(path)

class BaseXlsx:
    def __init__(self):
        self.wb = Workbook()
        self.ws = self.wb.active
        self.header_font = Font(bold=True, color="FFFFFF")
        self.header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
        self.thin_border = Border(
            left=Side(style='thin'), right=Side(style='thin'),
            top=Side(style='thin'), bottom=Side(style='thin')
        )
    
    def write_header(self, headers):
        for col, h in enumerate(headers, 1):
            cell = self.ws.cell(row=1, column=col, value=h)
            cell.font = self.header_font
            cell.fill = self.header_fill
            cell.alignment = Alignment(horizontal='center')
            cell.border = self.thin_border
    
    def write_rows(self, data, start_row=2):
        for r_idx, row in enumerate(data, start_row):
            for c_idx, val in enumerate(row, 1):
                cell = self.ws.cell(row=r_idx, column=c_idx, value=val)
                cell.border = self.thin_border
                cell.alignment = Alignment(wrap_text=True)
    
    def save(self, filename):
        path = OUTPUT_DIR / filename
        self.wb.save(path)
        return str(path)

class BasePptx:
    def __init__(self):
        self.prs = Presentation()
        self.prs.slide_width = PptxInches(13.333)
        self.prs.slide_height = PptxInches(7.5)
    
    def add_title_slide(self, title, subtitle=""):
        slide = self.prs.slides.add_slide(self.prs.slide_layouts[0])
        slide.shapes.title.text = title
        if len(slide.placeholders) > 1:
            slide.placeholders[1].text = subtitle
    
    def add_content_slide(self, title, bullets):
        slide = self.prs.slides.add_slide(self.prs.slide_layouts[1])
        slide.shapes.title.text = title
        tf = slide.placeholders[1].text_frame
        tf.clear()
        for i, b in enumerate(bullets):
            p = tf.add_paragraph() if i > 0 else tf.paragraphs[0]
            p.text = b
            p.level = 0
            p.font.size = PptxPt(18)
    
    def save(self, filename):
        path = OUTPUT_DIR / filename
        self.prs.save(path)
        return str(path)

class BasePdf(FPDF):
    def __init__(self):
        super().__init__()
        self.add_page()
        self.set_auto_page_break(auto=True, margin=15)
        self.set_font("Helvetica", size=11)
    
    def header_title(self, title):
        self.set_font("Helvetica", "B", 16)
        self.cell(0, 10, title, ln=True, align="C")
        self.ln(5)
    
    def section(self, title):
        self.set_font("Helvetica", "B", 13)
        self.cell(0, 8, title, ln=True)
        self.ln(2)
    
    def body(self, text):
        self.set_font("Helvetica", "", 11)
        self.multi_cell(0, 6, text)
        self.ln(3)
    
    def save(self, filename):
        path = OUTPUT_DIR / filename
        self.output(str(path))
        return str(path)


# === Document Type Generators ===

def generate_mom(workspace, user, content, template_id=None):
    """Minutes of Meeting generator"""
    doc_id = str(uuid.uuid4())[:8]
    
    # DOCX
    doc = BaseDocx()
    doc.add_heading("NOTULA RAPAT (Minutes of Meeting)", 0)
    doc.add_para(f"ID Dokumen: {doc_id} | Template: {template_id or 'default'} | Workspace: {workspace} | User: {user}")
    doc.add_heading("1. Informasi Umum", 1)
    doc.add_table(5, 2, [
        ["Tanggal", content.get("tanggal", "-")],
        ["Waktu", content.get("waktu", "-")],
        ["Tempat/Platform", content.get("tempat", "-")],
        ["Pencatat", content.get("pencatat", "-")]
    ], headers=["Item", "Detail"])
    
    doc.add_heading("2. Daftar Hadir", 1)
    attendees = content.get("hadir", [])
    if attendees:
        doc.add_table(len(attendees)+1, 3, attendees, headers=["Nama", "Jabatan", "Organisasi"])
    else:
        doc.add_para("Tidak ada data kehadiran.")
    
    doc.add_heading("3. Agenda & Pembahasan", 1)
    for i, agenda in enumerate(content.get("agenda", []), 1):
        doc.add_para(f"Agenda {i}: {agenda.get('topik', '')}", bold=True)
        doc.add_para(agenda.get("ringkasan", ""))
        if "keputusan" in agenda:
            doc.add_para(f"Keputusan: {agenda['keputusan']}", bold=True)
        if "action_items" in agenda:
            doc.add_heading("Action Items", 2)
            for act in agenda["action_items"]:
                doc.add_para(f"- {act.get('tugas', '')} | PIC: {act.get('pic', '')} | Deadline: {act.get('deadline', '')}")
    
    doc.add_heading("4. Penutup", 1)
    doc.add_para(content.get("catatan_penutup", "Rapat ditutup pada waktu yang ditentukan."))
    docx_path = doc.save(f"MoM_{doc_id}.docx")
    
    # PDF
    pdf = BasePdf()
    pdf.header_title("NOTULA RAPAT")
    pdf.body(f"ID: {doc_id} | Template: {template_id or 'default'}")
    pdf.section("Informasi Umum")
    for item, val in [("Tanggal", content.get("tanggal")), ("Waktu", content.get("waktu")), ("Tempat", content.get("tempat"))]:
        pdf.body(f"{item}: {val}")
    pdf.section("Agenda & Keputusan")
    for i, agenda in enumerate(content.get("agenda", []), 1):
        pdf.body(f"{i}. {agenda.get('topik', '')}")
        pdf.body(f"   Ringkasan: {agenda.get('ringkasan', '')}")
        if "keputusan" in agenda:
            pdf.body(f"   Keputusan: {agenda['keputusan']}")
    pdf_path = pdf.save(f"MoM_{doc_id}.pdf")
    
    return {"docx": docx_path, "pdf": pdf_path, "doc_id": doc_id}

def generate_dpp(workspace, user, content, template_id=None):
    """DPP / Daftar Pengeluaran Proyek generator"""
    doc_id = str(uuid.uuid4())[:8]
    
    # XLSX
    xlsx = BaseXlsx()
    xlsx.ws.title = "DPP"
    items = content.get("items", [])
    headers = ["No", "Kode", "Uraian", "Volume", "Satuan", "Harga Satuan", "Jumlah", "Keterangan"]
    xlsx.write_header(headers)
    data = []
    for i, item in enumerate(items, 1):
        vol = float(item.get("volume", 0))
        hs = float(item.get("harga_satuan", 0))
        data.append([i, item.get("kode", ""), item.get("uraian", ""), vol, item.get("satuan", ""), hs, vol*hs, item.get("keterangan", "")])
    # Add subtotal row
    subtotal = sum(d[6] for d in data)
    ppn = subtotal * 0.11
    data.append(["", "", "SUBTOTAL", "", "", "", subtotal, ""])
    data.append(["", "", "PPN (11%)", "", "", "", ppn, ""])
    data.append(["", "", "TOTAL", "", "", "", subtotal + ppn, ""])
    xlsx.write_rows(data)
    xlsx_path = xlsx.save(f"DPP_{doc_id}.xlsx")
    
    # DOCX Summary
    doc = BaseDocx()
    doc.add_heading("DAFTAR PENGELUARAN PROYEK (DPP)", 0)
    doc.add_para(f"ID: {doc_id} | Proyek: {content.get('nama_proyek', '-')}")
    doc.add_heading("Ringkasan Biaya", 1)
    doc.add_table(4, 2, [
        ["Subtotal", f"Rp {subtotal:,.0f}"],
        ["PPN (11%)", f"Rp {ppn:,.0f}"],
        ["TOTAL", f"Rp {subtotal + ppn:,.0f}"]
    ], headers=["Keterangan", "Jumlah"])
    docx_path = doc.save(f"DPP_{doc_id}.docx")
    
    return {"xlsx": xlsx_path, "docx": docx_path, "doc_id": doc_id}

def generate_tor(workspace, user, content, template_id=None):
    """Terms of Reference / KAK generator"""
    doc_id = str(uuid.uuid4())[:8]
    
    doc = BaseDocx()
    doc.add_heading("TERMS OF REFERENCE (ToR) / KERANGKA ACUAN KERJA (KAK)", 0)
    doc.add_para(f"ID Dokumen: {doc_id} | Template: {template_id or 'default'}")
    
    sections = [
        ("1. Latar Belakang", content.get("latar_belakang", "")),
        ("2. Ruang Lingkup Pekerjaan", content.get("ruang_lingkup", "")),
        ("3. Tujuan & Sasaran", content.get("tujuan", "")),
        ("4. Metodologi & Pendekatan", content.get("metodologi", "")),
        ("5. Timeline & Milestone", content.get("timeline", "")),
        ("6. Rencana Anggaran Biaya (RAB)", content.get("rab", "")),
        ("7. Deliverables", content.get("deliverables", "")),
        ("8. Tim Proyek", content.get("tim", "")),
        ("9. Ketentuan Lain", content.get("ketentuan", "")),
    ]
    for title, body in sections:
        doc.add_heading(title, 1)
        if isinstance(body, list):
            for item in body:
                doc.add_para(f"- {item}")
        else:
            doc.add_para(str(body))
    
    docx_path = doc.save(f"ToR_{doc_id}.docx")
    
    # PDF
    pdf = BasePdf()
    pdf.header_title("TERMS OF REFERENCE (ToR)")
    pdf.body(f"ID: {doc_id}")
    for title, body in sections:
        pdf.section(title)
        if isinstance(body, list):
            for item in body:
                pdf.body(f"  - {item}")
        else:
            pdf.body(str(body))
    pdf_path = pdf.save(f"ToR_{doc_id}.pdf")
    
    return {"docx": docx_path, "pdf": pdf_path, "doc_id": doc_id}

def generate_jurnal(workspace, user, content, template_id=None):
    """Jurnal Ilmiah generator (2 kolom style)"""
    doc_id = str(uuid.uuid4())[:8]
    
    doc = BaseDocx()
    doc.add_heading(content.get("judul", "JUDUL JURNAL"), 0)
    doc.add_para(f"Penulis: {content.get('penulis', '-')}")
    doc.add_para(f"Institusi: {content.get('institusi', '-')}")
    doc.add_para(f"Email: {content.get('email', '-')}")
    doc.add_para("")  # spacer
    
    # Abstract
    doc.add_heading("Abstrak", 1)
    doc.add_para(content.get("abstrak", ""))
    doc.add_para(f"Kata Kunci: {content.get('kata_kunci', '')}")
    
    sections = [
        ("1. Pendahuluan", content.get("pendahuluan", "")),
        ("2. Tinjauan Pustaka", content.get("tinjauan_pustaka", "")),
        ("3. Metodologi", content.get("metodologi", "")),
        ("4. Hasil dan Pembahasan", content.get("hasil_pembahasan", "")),
        ("5. Kesimpulan", content.get("kesimpulan", "")),
        ("6. Daftar Pustaka", content.get("daftar_pustaka", "")),
    ]
    for title, body in sections:
        doc.add_heading(title, 1)
        if isinstance(body, list):
            for item in body:
                doc.add_para(f"- {item}")
        else:
            doc.add_para(str(body))
    
    docx_path = doc.save(f"Jurnal_{doc_id}.docx")
    
    # PDF
    pdf = BasePdf()
    pdf.header_title(content.get("judul", "JUDUL JURNAL"))
    pdf.body(f"Penulis: {content.get('penulis', '-')}")
    pdf.body(f"Institusi: {content.get('institusi', '-')}")
    pdf.ln(3)
    pdf.section("Abstrak")
    pdf.body(content.get("abstrak", ""))
    pdf.body(f"Kata Kunci: {content.get('kata_kunci', '')}")
    for title, body in sections:
        pdf.section(title)
        if isinstance(body, list):
            for item in body:
                pdf.body(f"  - {item}")
        else:
            pdf.body(str(body))
    pdf_path = pdf.save(f"Jurnal_{doc_id}.pdf")
    
    return {"docx": docx_path, "pdf": pdf_path, "doc_id": doc_id}

def generate_ta(workspace, user, content, template_id=None):
    """Tugas Akhir / Skripsi generator"""
    doc_id = str(uuid.uuid4())[:8]
    
    doc = BaseDocx()
    # Cover
    for _ in range(4):
        doc.add_para("")
    doc.add_para(content.get("judul", "JUDUL TUGAS AKHIR"), bold=True)
    doc.add_para("")
    doc.add_para(f"Disusun oleh: {content.get('penulis', '-')}")
    doc.add_para(f"NIM: {content.get('nim', '-')}")
    doc.add_para(f"Program Studi: {content.get('prodi', '-')}")
    doc.add_para(f"Fakultas: {content.get('fakultas', '-')}")
    doc.add_para(f"Universitas: {content.get('universitas', '-')}")
    doc.add_para(f"Tahun: {content.get('tahun', '-')}")
    
    # Add page break
    doc.doc.add_page_break()
    
    # Contents
    chapters = [
        ("BAB I PENDAHULUAN", content.get("bab1", {})),
        ("BAB II TINJAUAN PUSTAKA", content.get("bab2", {})),
        ("BAB III METODOLOGI PENELITIAN", content.get("bab3", {})),
        ("BAB IV HASIL DAN PEMBAHASAN", content.get("bab4", {})),
        ("BAB V KESIMPULAN DAN SARAN", content.get("bab5", {})),
    ]
    for title, chapter in chapters:
        doc.add_heading(title, 1)
        for sub_title, sub_content in chapter.items():
            doc.add_heading(sub_title, 2)
            doc.add_para(str(sub_content))
    
    # Lampiran
    doc.add_heading("LAMPIRAN", 1)
    for i, lamp in enumerate(content.get("lampiran", []), 1):
        doc.add_para(f"Lampiran {i}: {lamp}")
    
    docx_path = doc.save(f"TA_{doc_id}.docx")
    
    # PDF
    pdf = BasePdf()
    for _ in range(3):
        pdf.ln(10)
    pdf.header_title(content.get("judul", "JUDUL TUGAS AKHIR"))
    pdf.body(f"Disusun oleh: {content.get('penulis', '-')}")
    pdf.body(f"NIM: {content.get('nim', '-')}")
    pdf.body(f"Program Studi: {content.get('prodi', '-')}")
    pdf.body(f"Fakultas: {content.get('fakultas', '-')}")
    pdf.body(f"Universitas: {content.get('universitas', '-')}")
    pdf.body(f"Tahun: {content.get('tahun', '-')}")
    pdf.add_page()
    
    for title, chapter in chapters:
        pdf.section(title)
        for sub_title, sub_content in chapter.items():
            pdf.section(sub_title)
            pdf.body(str(sub_content))
    
    pdf_path = pdf.save(f"TA_{doc_id}.pdf")
    
    return {"docx": docx_path, "pdf": pdf_path, "doc_id": doc_id}


# === Router ===

GENERATORS = {
    "MoM": generate_mom,
    "DPP": generate_dpp,
    "ToR": generate_tor,
    "Jurnal": generate_jurnal,
    "TA": generate_ta,
}

def generate_document(doc_type: str, workspace: str, user: str, content: dict, template_id: str = None):
    if doc_type not in GENERATORS:
        raise ValueError(f"Unknown doc_type: {doc_type}. Available: {list(GENERATORS.keys())}")
    return GENERATORS[doc_type](workspace, user, content, template_id)