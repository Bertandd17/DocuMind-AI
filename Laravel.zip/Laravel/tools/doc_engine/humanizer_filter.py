import re

def humanize(text: str) -> str:
    # 1. Strip typical AI cliché transitions and openers
    cliches = [
        r"^(Certainly!|Sure!|Here is|Here's an overview|In summary|To summarize|Furthermore,|Moreover,|In conclusion,|Delves into|It is important to remember that|As an AI language model,)\s*",
        r"\b(delve into|tapestry of|vital role|beacon of|testament to|paramount importance)\b"
    ]
    cleaned = text
    for pattern in cliches:
        cleaned = re.sub(pattern, "", cleaned, flags=re.IGNORECASE | re.MULTILINE)
    
    # 2. Trim excess whitespace and cleanup formatting
    cleaned = re.sub(r"\n{3,}", "\n\n", cleaned)
    return cleaned.strip()

def analyze_ai_probability(text: str) -> float:
    # Basic heuristic check for AI phrasing density
    ai_markers = ["furthermore", "moreover", "in conclusion", "comprehensive", "delve", "pivotal", "vital role", "seamless"]
    matches = sum(1 for m in ai_markers if m in text.lower())
    score = min(1.0, matches * 0.15)
    return round(score, 2)
