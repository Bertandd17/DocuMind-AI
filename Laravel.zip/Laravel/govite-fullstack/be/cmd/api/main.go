// Command api runs the HTTP server and its maintenance subcommands:
//
//	api                 serve (default)
//	api migrate [cmd]   goose command, default "up"
//	api seed            sync permissions, Super Admin role and user
//	api healthcheck     exit 0 when the local server answers /health/live
package main

import (
	"context"
	"fmt"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"strings"
	"syscall"
	"time"

	"github.com/getsentry/sentry-go"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/redis/go-redis/v9"

	"govite/internal/kernel"
	"govite/internal/platform/config"
	"govite/internal/platform/crypto"
	"govite/internal/platform/fcm"
	"govite/internal/platform/mail"
	postgres "govite/internal/platform/postgres"
	"govite/internal/platform/postgres/store"
	"govite/internal/platform/storage"
	"govite/internal/policy"
	"govite/internal/server"
)

func main() {
	if err := run(); err != nil {
		slog.Error("fatal", "err", err)
		os.Exit(1)
	}
}

func run() error {
	// healthcheck runs inside the distroless image (no curl/shell), so it must
	// not need DATABASE_URL or secrets.
	if len(os.Args) > 1 && os.Args[1] == "healthcheck" {
		return healthcheck()
	}
	cfg, err := config.Load()
	if err != nil {
		return err
	}
	setupLogger(cfg.LogLevel)
	if cfg.SentryDSN != "" {
		if err := sentry.Init(sentry.ClientOptions{Dsn: cfg.SentryDSN, Environment: cfg.SentryEnvironment, EnableTracing: true}); err != nil {
			return err
		}
		defer sentry.Flush(2 * time.Second)
	}
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	pool, err := newPool(ctx, cfg.DatabaseURL)
	if err != nil {
		return err
	}
	defer pool.Close()

	cmd := "serve"
	if len(os.Args) > 1 {
		cmd = os.Args[1]
	}
	switch cmd {
	case "migrate":
		goose := "up"
		if len(os.Args) > 2 {
			goose = os.Args[2]
		}
		return postgres.Migrate(ctx, pool, goose, os.Args[min(3, len(os.Args)):]...)
	case "seed":
		return seed(ctx, cfg, store.New(pool))
	case "serve":
		return serve(ctx, cfg, pool)
	default:
		return fmt.Errorf("unknown command %q (serve|migrate|seed)", cmd)
	}
}

// newPool caps how long one statement may hold a connection, so a stuck query
// cannot starve the pool. Override in DATABASE_URL (?statement_timeout=...) if
// a migration needs longer.
func newPool(ctx context.Context, url string) (*pgxpool.Pool, error) {
	pc, err := pgxpool.ParseConfig(url)
	if err != nil {
		return nil, err
	}
	if _, set := pc.ConnConfig.RuntimeParams["statement_timeout"]; !set {
		pc.ConnConfig.RuntimeParams["statement_timeout"] = "30000"
	}
	pc.MaxConnLifetime, pc.HealthCheckPeriod = time.Hour, time.Minute
	return pgxpool.NewWithConfig(ctx, pc)
}

func serve(ctx context.Context, cfg config.Config, pool *pgxpool.Pool) error {
	d := server.Deps{Cfg: cfg, Pool: pool}
	if cfg.RedisURL != "" {
		opt, err := redis.ParseURL(cfg.RedisURL)
		if err != nil {
			return fmt.Errorf("REDIS_URL: %w", err)
		}
		d.Redis = redis.NewClient(opt)
		defer d.Redis.Close()
		if err := d.Redis.Ping(ctx).Err(); err != nil {
			slog.Warn("redis unreachable at boot; cache and limiter will retry", "err", err)
		}
	}
	d.Mail = mail.NewSMTP(cfg.SMTPHost, cfg.SMTPPort, cfg.SMTPUsername, cfg.SMTPPassword, cfg.SMTPFrom, server.Brand(server.Settings(pool)))
	var err error
	d.Files, err = storage.New(storage.Config{Endpoint: cfg.MinioEndpoint, AccessKey: cfg.MinioAccessKey, SecretKey: cfg.MinioSecretKey, Bucket: cfg.MinioBucket, UseSSL: cfg.MinioUseSSL, PublicEndpoint: cfg.MinioPublicEndpoint, PublicURL: cfg.StoragePublicURL})
	if err != nil {
		return err
	}
	if err := d.Files.EnsureBucket(ctx); err != nil {
		return err
	}
	if push, err := fcm.NewFCM(ctx, cfg.FirebaseServiceAccountPath); err != nil {
		slog.Error("firebase init failed; push disabled", "err", err)
	} else if push != nil { // a nil *FCM in the interface would look enabled
		d.Push = push
	}

	f, sys := server.New(d)
	daily := make(chan struct{})
	go func() { sys.RunDaily(ctx); close(daily) }()
	errc := make(chan error, 1)
	go func() { errc <- f.Listen(fmt.Sprintf(":%d", cfg.Port)) }()
	slog.Info("api listening", "port", cfg.Port, "env", cfg.Env)
	select {
	case err := <-errc:
		return err
	case <-ctx.Done():
		slog.Info("shutting down")
		err := f.ShutdownWithTimeout(10 * time.Second)
		// ctx is cancelled, so a running cleanup aborts and its transaction rolls
		// back; wait for that so the pool is not closed underneath it.
		select {
		case <-daily:
		case <-time.After(10 * time.Second):
			slog.Warn("maintenance cleanup still running at shutdown")
		}
		return err
	}
}

// SuperAdminRoleID is fixed so seed is idempotent across environments.
const SuperAdminRoleID = "019a0000-0000-7000-8000-000000000001"

func seed(ctx context.Context, cfg config.Config, q *store.Queries) error {
	keys := make([]string, len(policy.Permissions))
	for i, p := range policy.Permissions {
		keys[i] = p.Key()
		if err := q.SyncPermission(ctx, store.SyncPermissionParams{ID: kernel.NewID(), Resource: p.Resource, Action: p.Action}); err != nil {
			return err
		}
	}
	if err := q.DeleteUnknownPermissions(ctx, keys); err != nil {
		return err
	}
	desc := "Full system access"
	if err := q.UpsertSystemRole(ctx, store.UpsertSystemRoleParams{ID: SuperAdminRoleID, Name: "Super Admin", Description: &desc}); err != nil {
		return err
	}
	for _, p := range policy.Permissions {
		if err := q.UpsertRolePermission(ctx, store.UpsertRolePermissionParams{ID: kernel.NewID(), RoleID: SuperAdminRoleID, Resource: p.Resource, Action: p.Action, Scope: "all"}); err != nil {
			return err
		}
	}
	if cfg.SuperAdminEmail == "" || cfg.SuperAdminPassword == "" {
		return fmt.Errorf("SUPER_ADMIN_EMAIL and SUPER_ADMIN_PASSWORD are required")
	}
	hash, err := crypto.HashPassword(cfg.SuperAdminPassword)
	if err != nil {
		return err
	}
	if err := q.UpsertSuperAdmin(ctx, store.UpsertSuperAdminParams{ID: kernel.NewID(), Email: cfg.SuperAdminEmail, RoleID: SuperAdminRoleID, PasswordHash: &hash}); err != nil {
		return err
	}
	slog.Info("seed done", "permissions", len(keys), "superAdmin", cfg.SuperAdminEmail)
	return nil
}

func healthcheck() error {
	port := os.Getenv("APP_PORT")
	if port == "" {
		port = "3000"
	}
	client := http.Client{Timeout: 3 * time.Second}
	res, err := client.Get("http://127.0.0.1:" + port + "/api/v1/health/live")
	if err != nil {
		return err
	}
	defer res.Body.Close()
	if res.StatusCode != http.StatusOK {
		return fmt.Errorf("health/live: %s", res.Status)
	}
	return nil
}

func setupLogger(level string) {
	var l slog.Level
	switch strings.ToLower(level) {
	case "debug":
		l = slog.LevelDebug
	case "warn":
		l = slog.LevelWarn
	case "error", "silent":
		l = slog.LevelError
	default:
		l = slog.LevelInfo
	}
	slog.SetDefault(slog.New(slog.NewJSONHandler(os.Stdout, &slog.HandlerOptions{Level: l})))
}
