# Product Requirement Document (PRD)
## AI-Powered Document Generation Platform

---

## 1. Document Overview
* **Project Name:** AI Document Studio & Generator (Laravel-based)
* **Document Version:** 1.0.0
* **Status:** Draft
* **Target Stack:** Laravel 11+, Vue.js / Inertia.js or Blade + TailwindCSS, Python Microservice (Document Engine), 9Router API Integration.

---

## 2. Product Summary
Platform berbasis web yang dirancang untuk membuat, meniru (cloning), dan mengedit dokumen secara otomatis berbasis AI. Aplikasi ini menggunakan antarmuka percakapan interaktif mirip Claude.ai dengan bilah sisi (*sidebar*) untuk manajemen *template* dan *skills*. Otak utama AI terhubung ke **9Router VPS** (Multi-LLM Router) untuk memproses teks, analisis *template*, serta pembuatan output dokumen dalam format **Word (.docx), Excel (.xlsx), PowerPoint (.pptx), dan PDF (.pdf)**.

---

## 3. Key Core Objectives
1. **Document Cloning & Extraction:** Memungkinkan pengguna mengunggah dokumen eksisting (PDF/Word/Excel/PPT) untuk diekstrak struktur, *style*, dan variabelnya menjadi *template* siap pakai.
2. **Interactive Chat Workspace:** Antarmuka percakapan utama untuk memberikan instruksi *generate* dokumen, revisi, dan tanya jawab dengan konteks dokumen.
3. **9Router AI Engine Integration:** Mengarahkan *prompting* dan pemrosesan AI ke *cluster/endpoint* 9Router VPS milik pengguna.
4. **Custom Skill Loader:** Pengguna dapat mengunggah *skills* (instruksi spesifik, aturan format, *knowledge base*, atau aturan penulisan) yang bisa dipasang pada obrolan aktif.
5. **Multi-Format Document Builder:** Mendukung pembuatan file akhir secara akurat dalam format Word, Excel, PowerPoint, dan PDF.

---

## 4. User Persona & Use Cases
* **Target User:** Business Analysts, Content Creators, Corporate Administrators, & Academics.
* **Primary Use Case:**
  1. Pengguna mengunggah laporan Excel lama sebagai *template*.
  2. Pengguna mengunggah *Skill* (misal: "Aturan Laporan Keuangan Standard IFRS").
  3. Melalui fitur chat, pengguna meminta AI: *"Buatkan laporan keuangan kuartal 3 berdasarkan template yang ada dan ikuti aturan skill IFRS."*
  4. Platform memproses instruksi via 9Router dan menghasilkan file `.xlsx` / `.pdf` siap unduh.

---

## 5. Feature Requirements

### 5.1. User Interface (UI/UX) - Claude-style Layout
* **Left Sidebar:**
  * **New Chat / New Session:** Membuka ruang percakapan baru.
  * **Template Manager:** Daftar *template* dokumen (Word, Excel, PPT, PDF) yang pernah diunggah/dibuat. Pengguna bisa memilih *template* aktif untuk obrolan saat ini.
  * **Skill Loader Library:** Daftar *skill/custom instructions* yang tersimpan. Pengguna dapat memilih/mengaktifkan satu atau beberapa *skill* sekaligus.
  * **History Logs:** History percakapan & dokumen yang pernah dibuat.
* **Main Canvas (Center):**
  * **Chat Area:** Area percakapan interaktif dengan *streaming text response*.
  * **Document Preview / Output Area:** Split-screen atau modal pop-up untuk melihat *preview* dokumen hasil *generate* sebelum diunduh.
  * **Attachment Button:** Tombol *upload* file instan di dalam kolom chat untuk ekstrak cepat.

---

### 5.2. Core Module Details

#### Module A: 9Router AI Integration (Brain)
* **API Connector:** Menghubungkan Laravel ke 9Router VPS via REST API / OpenAPI endpoints.
* **Model Selector:** Memungkinkan pengguna memilih model LLM yang aktif dari 9Router (misal: Llama-3, Claude, GPT-4, DeepSeek, dll. sesuai yang terdaftar di 9Router).
* **Context & Token Management:** Menangani pembagian konteks untuk *prompting* dokumen panjang (*chunking* & RAG dasar jika diperlukan).

#### Module B: Template System & Cloning Engine
* **Template Upload:** Pengguna dapat mengunggah file `.docx`, `.xlsx`, `.pptx`, atau `.pdf`.
* **Template Parsing:** AI mengekstrak struktur dokumen, gaya font, tabel, header, footer, dan menandai *placeholder* variabel (seperti `{{nama_perusahaan}}`, `{{tabel_penjualan}}`).
* **Template Storage:** Menyimpan struktur *template* di *database* (JSON structure & raw layout).

#### Module C: Skill Loader Engine
* **Upload Custom Skill:** Mendukung format file `.txt`, `.markdown`, atau form input manual berisi instruksi khusus.
* **Skill Injection:** Menuliskan aturan *skills* yang diunggah secara otomatis ke dalam *system prompt* sebelum dikirim ke 9Router.

#### Module D: Multi-Format Document Renderer
* **Word Engine (`.docx`):** Menggunakan PhpSpreadsheet / PHPWord atau Python Microservice (python-docx) untuk mengisikan data ke *template*.
* **Excel Engine (`.xlsx`):** Mengisi tabel, formula, dan grafik otomatis menggunakan PhpSpreadsheet atau openpyxl.
* **PowerPoint Engine (`.pptx`):** Membuat slide presentasi berbasis *layout master* menggunakan PHPPresentation atau python-pptx.
* **PDF Engine (`.pdf`):** Mengonversi Word/Excel/HTML ke PDF beresolusi tinggi (Dompdf, Browsershot/Puppeteer, atau LibreOffice CLI).

---

## 6. System Architecture & Tech Stack

```
   +-------------------------------------------------------------+
   |                        FRONTEND                             |
   |   Inertia.js / Vue 3 + Tailwind CSS (Claude-like UX)        |
   +------------------------------+------------------------------+
                                  |
                                  v
   +-------------------------------------------------------------+
   |                    LARAVEL BACKEND                          |
   |  - Auth & User Workspace                                    |
   |  - File & Media Storage (S3 / Local)                        |
   |  - Chat & Prompt Builder Manager                             |
   |  - Template & Skill Parser Services                         |
   +---------------+\----------------------------+/--------------+
                   | \                          / |
                   |  \                        /  |
                   v   v                      v   v
+--------------------+ +--------------------+ +--------------------+
|   9Router VPS API  | |  Document Engine   | | Database & Storage |
|  (AI Brain/LLMs)   | | (PHP/Python Parser)| | (PostgreSQL/S3)    |
+--------------------+ +--------------------+ +--------------------+
```

* **Backend:** Laravel 11 (PHP 8.2+)
* **Frontend:** Vue 3 / Inertia.js + Tailwind CSS
* **Database:** PostgreSQL / MySQL
* **Queue System:** Laravel Horizon + Redis (untuk menangani *processing* dokumen berukuran besar secara *asynchronous*).
* **Document Processing:** 
  * PHP: `phpoffice/phpword`, `phpoffice/phpspreadsheet`, `dompdf/dompdf`
  * Alternative/Recommended: Python microservice (`python-docx`, `openpyxl`, `python-pptx`, `pdfplumber`) untuk *parsing* yang lebih presisi.

---

## 7. User Flow (Step-by-Step)

```
1. User Login -> Buka Dashboard (Workspace)
2. User mengunggah File Template ke Sidebar (misal: "Surat Kontrak.docx")
3. AI menganalisis "Surat Kontrak.docx" via 9Router -> Menyimpan variabel template
4. User mengunggah Skill ke Sidebar (misal: "Aturan Hukum Perusahaan.md")
5. User melakukan Chat:
   "Tolong buatkan Surat Kontrak untuk Klien PT ABC dengan nilai kontrak 100 Juta."
6. Laravel menggabungkan (System Prompt + Skill + Template Variables + User Prompt)
7. Request dikirim ke 9Router VPS -> AI mengembalikan JSON Data/Content
8. Document Engine menyusun file .docx / .pdf akhir
9. User menerima link preview/download dokumen hasil generate di dalam Chat window
```

---

## 8. Non-Functional Requirements
* **Security:** Sanitisasi file unggahan (*anti-malware scan*), enkripsi kunci API 9Router, dan isolasi file antar pengguna.
* **Performance:** *Generate* dokumen sederhana (< 5 halaman) harus selesai dalam < 10 detik. Penggunaan Laravel Queue untuk *job* berat.
* **Scalability:** Kemampuan berpindah antar model LLM di 9Router jika ada model yang *overload*.

---

## 9. Future Roadmap / Development Phases
* **Phase 1 (MVP):** Setup Laravel, Integrasi API 9Router, Chat UI sederhana, *Parsing* & *Generation* untuk Word (.docx) dan PDF.
* **Phase 2:** Integrasi Excel (.xlsx) & PowerPoint (.pptx), Fitur *Template Auto-Cloning*, dan *Skill Loader*.
* **Phase 3:** *Live Document Editor/Preview* di browser, *multi-skill injection*, dan kolaborasi tim.